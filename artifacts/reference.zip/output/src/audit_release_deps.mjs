import fs from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const outputDir = path.join(root, 'output', 'reports');

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') { cell += '"'; index += 1; }
      else if (char === '"') quoted = false;
      else cell += char;
    } else if (char === '"') quoted = true;
    else if (char === ',') { row.push(cell); cell = ''; }
    else if (char === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += char;
  }
  if (cell || row.length) { row.push(cell.replace(/\r$/, '')); rows.push(row); }
  const headers = rows.shift() ?? [];
  return rows.filter((values) => values.some(Boolean)).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ''])),
  );
}

function csvEscape(value) {
  const text = String(value ?? '');
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function toCsv(headers, rows) {
  return [headers.join(','), ...rows.map((row) => headers.map((header) => csvEscape(row[header])).join(','))].join('\n') + '\n';
}

function packageNameFromPath(packagePath) {
  const marker = 'node_modules/';
  const index = packagePath.lastIndexOf(marker);
  return packagePath.slice(index + marker.length);
}

function resolveDependencyPath(packages, parentPath, dependencyName) {
  if (parentPath) {
    const nested = `${parentPath}/node_modules/${dependencyName}`;
    if (packages[nested]) return nested;
  }
  const hoisted = `node_modules/${dependencyName}`;
  if (packages[hoisted]) return hoisted;
  throw new Error(`lockfile entry not found for ${dependencyName}, parent=${parentPath || '<root>'}`);
}

function ownerFor(packageName, parentOwner, ownerRules) {
  const exact = ownerRules.find((rule) => rule.package_pattern === packageName);
  if (exact) return exact.owner_team;
  const wildcard = ownerRules.find((rule) => rule.package_pattern.endsWith('*') && packageName.startsWith(rule.package_pattern.slice(0, -1)));
  if (wildcard) return wildcard.owner_team;
  return parentOwner || 'unassigned';
}

function licenseDecision(rawLicense, policy) {
  const normalized = policy.license_aliases[rawLicense] ?? rawLicense;
  if (policy.allowed_licenses.includes(normalized)) return { normalized, status: 'allow', finding: 'policy_allow' };
  if (policy.review_licenses.includes(normalized)) return { normalized, status: 'review', finding: 'manual_review_required' };
  if (policy.prohibited_licenses.includes(normalized)) return { normalized, status: 'prohibit', finding: 'prohibited_license' };
  return { normalized, status: 'prohibit', finding: 'unclassified_license' };
}

function exceptionStatus(vulnerability, reportDate) {
  if (!vulnerability.exception_id || !vulnerability.exception_expires_on) return 'none';
  const expiry = Date.parse(`${vulnerability.exception_expires_on}T23:59:59Z`);
  const report = Date.parse(`${reportDate}T00:00:00Z`);
  if (!Number.isFinite(expiry) || !Number.isFinite(report)) throw new Error('invalid policy or exception date');
  return expiry >= report ? 'active' : 'expired';
}

function vulnerabilityDecision(vulnerability, status, policy) {
  const configured = policy.vulnerability_gate[vulnerability.severity];
  if (!configured) throw new Error(`missing vulnerability gate for severity ${vulnerability.severity}`);
  if (configured === 'block_always') return 'block';
  if (configured === 'allow_with_active_exception') return status === 'active' ? 'allow_with_exception' : 'block';
  throw new Error(`unsupported vulnerability gate ${configured} for severity ${vulnerability.severity}`);
}

const lockfile = JSON.parse(await fs.readFile(path.join(root, 'package-lock.json'), 'utf8'));
const policy = JSON.parse(await fs.readFile(path.join(root, 'rules/license_policy.json'), 'utf8'));
const vulnerabilities = JSON.parse(await fs.readFile(path.join(root, 'security/vulnerability_feed.json'), 'utf8'));
const ownerRules = parseCsv(await fs.readFile(path.join(root, 'owners.csv'), 'utf8'));
if (lockfile.lockfileVersion !== 3 || !lockfile.packages?.['']) throw new Error('package-lock v3 with a root package is required');

const rootDependencies = Object.keys(lockfile.packages[''].dependencies ?? {});
const queue = rootDependencies.map((name) => ({
  name,
  packagePath: resolveDependencyPath(lockfile.packages, '', name),
  parent: '',
  parentOwner: '',
  direct: true
}));
const inventory = [];
const seenPaths = new Set();
while (queue.length) {
  const item = queue.shift();
  if (seenPaths.has(item.packagePath)) continue;
  seenPaths.add(item.packagePath);
  const packageEntry = lockfile.packages[item.packagePath];
  const actualName = packageNameFromPath(item.packagePath);
  if (actualName !== item.name) throw new Error(`package path/name mismatch: ${item.packagePath} vs ${item.name}`);
  const owner = ownerFor(item.name, item.parentOwner, ownerRules);
  const license = licenseDecision(packageEntry.license ?? '', policy);
  const record = {
    package_name: item.name,
    version: packageEntry.version,
    path: item.packagePath,
    direct: item.direct ? 'yes' : 'no',
    parent: item.parent,
    owner_team: owner,
    normalized_license: license.normalized,
    license_status: license.status,
    license_finding: license.finding,
    gate_action: license.status === 'prohibit' ? 'block' : license.status === 'review' ? 'manual_review' : 'allow'
  };
  inventory.push(record);
  for (const childName of Object.keys(packageEntry.dependencies ?? {})) {
    queue.push({
      name: childName,
      packagePath: resolveDependencyPath(lockfile.packages, item.packagePath, childName),
      parent: item.name,
      parentOwner: owner,
      direct: false
    });
  }
}

const inventoryByKey = new Map(inventory.map((row) => [`${row.package_name}@${row.version}`, row]));
const vulnerabilityRows = vulnerabilities.map((vulnerability) => {
  const inventoryRow = inventoryByKey.get(`${vulnerability.package_name}@${vulnerability.affected_version}`);
  if (!inventoryRow) throw new Error(`vulnerability does not match lockfile: ${vulnerability.package_name}@${vulnerability.affected_version}`);
  const status = exceptionStatus(vulnerability, policy.report_date);
  const gateAction = vulnerabilityDecision(vulnerability, status, policy);
  if (gateAction === 'block') inventoryRow.gate_action = 'block';
  else if (inventoryRow.gate_action === 'allow') inventoryRow.gate_action = gateAction;
  return {
    package_name: vulnerability.package_name,
    version: vulnerability.affected_version,
    advisory_id: vulnerability.advisory_id,
    severity: vulnerability.severity,
    exception_id: vulnerability.exception_id,
    exception_status: status,
    gate_action: gateAction,
    owner_team: inventoryRow.owner_team
  };
});

const licenseRows = inventory.map((row) => ({
  package_name: row.package_name,
  version: row.version,
  normalized_license: row.normalized_license,
  license_status: row.license_status,
  owner_team: row.owner_team,
  finding: row.license_finding
}));
const inventoryRows = inventory.map((row) => ({
  package_name: row.package_name,
  version: row.version,
  path: row.path,
  direct: row.direct,
  parent: row.parent,
  owner_team: row.owner_team,
  normalized_license: row.normalized_license,
  gate_action: row.gate_action
}));

const blockers = [];
for (const row of vulnerabilityRows.filter((candidate) => candidate.gate_action === 'block')) {
  blockers.push({
    package_name: row.package_name,
    reason: `${row.severity}_vulnerability_${row.exception_status === 'expired' ? 'exception_expired' : 'no_exception'}`,
    advisory_id: row.advisory_id,
    owner_team: row.owner_team
  });
}
for (const row of licenseRows.filter((candidate) => candidate.license_status === 'prohibit')) {
  if (blockers.some((blocker) => blocker.package_name === row.package_name)) continue;
  blockers.push({
    package_name: row.package_name,
    reason: row.finding,
    advisory_id: '',
    owner_team: row.owner_team
  });
}
const warnings = [];
for (const row of licenseRows.filter((candidate) => candidate.license_status === 'review')) {
  warnings.push({ package_name: row.package_name, reason: 'license_manual_review', owner_team: row.owner_team });
}
for (const row of vulnerabilityRows.filter((candidate) => candidate.gate_action === 'allow_with_exception')) {
  warnings.push({
    package_name: row.package_name,
    reason: `${row.severity}_vulnerability_exception_active`,
    owner_team: row.owner_team
  });
}
const releaseDecision = {
  result: blockers.length ? 'BLOCK' : warnings.length ? 'REVIEW' : 'ALLOW',
  evaluated_at_utc: `${policy.report_date}T09:00:00Z`,
  dependency_count: inventoryRows.length,
  direct_dependency_count: inventoryRows.filter((row) => row.direct === 'yes').length,
  transitive_dependency_count: inventoryRows.filter((row) => row.direct === 'no').length,
  blockers,
  warnings
};

await fs.mkdir(outputDir, { recursive: true });
await fs.writeFile(path.join(outputDir, 'dependency_inventory.csv'), toCsv(
  ['package_name', 'version', 'path', 'direct', 'parent', 'owner_team', 'normalized_license', 'gate_action'], inventoryRows
));
await fs.writeFile(path.join(outputDir, 'license_findings.csv'), toCsv(
  ['package_name', 'version', 'normalized_license', 'license_status', 'owner_team', 'finding'], licenseRows
));
await fs.writeFile(path.join(outputDir, 'vulnerability_gate.csv'), toCsv(
  ['package_name', 'version', 'advisory_id', 'severity', 'exception_id', 'exception_status', 'gate_action', 'owner_team'], vulnerabilityRows
));
await fs.writeFile(path.join(outputDir, 'release_decision.json'), JSON.stringify(releaseDecision, null, 2) + '\n');
console.log(JSON.stringify(releaseDecision));
