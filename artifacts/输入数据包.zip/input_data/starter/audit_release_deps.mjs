import fs from 'node:fs/promises';

// TODO: 遍历package-lock.json，归并许可证，套用漏洞例外和owner归属，生成output/reports。
console.log('repair dependency audit');
