import fs from 'node:fs/promises';

// TODO: 遍历 package-lock.json，归并许可证，套用漏洞例外和 owner 归属，生成 output/reports。
console.log('repair dependency audit');
