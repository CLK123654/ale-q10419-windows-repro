import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const reports = path.join(root, 'output', 'reports');
const source = path.join(root, 'output', 'src', 'audit_release_deps.mjs');
const expectedReports = [
  'dependency_inventory.csv',
  'license_findings.csv',
  'release_decision.json',
  'vulnerability_gate.csv',
];
async function cleanReports() { await fs.rm(reports, { recursive: true, force: true }); }
async function main() {
  await cleanReports();
  const required = [
    'README.md',
    'package-lock.json',
    'owners.csv',
    'rules/license_policy.json',
    'security/vulnerability_feed.json',
    'starter/audit_release_deps.mjs',
  ];
  const missing = [];
  for (const relative of required) {
    try { await fs.access(path.join(root, relative)); } catch { missing.push(relative); }
  }
  if (missing.length) throw Object.assign(new Error(`missing inputs:${missing.join(',')}`), { exitCode: 2 });
  try { await fs.access(source); }
  catch { throw Object.assign(new Error('missing completed program:output/src/audit_release_deps.mjs'), { exitCode: 2 }); }
  const major = Number(process.versions.node.split('.')[0]);
  if (!Number.isInteger(major) || major < 20) throw new Error(`Node.js20 or newer required, found ${process.version}`);
  const run = spawnSync(process.execPath, [source], { cwd: root, encoding: 'utf8', windowsHide: true, timeout: 30000 });
  if (run.error) throw new Error(`audit process error:${run.error.message}`);
  if (run.status !== 0) throw new Error(`audit process failed:${run.stderr || run.stdout}`);
  const actual = (await fs.readdir(reports, { withFileTypes: true })).filter(entry => entry.isFile()).map(entry => entry.name).sort();
  if (JSON.stringify(actual) !== JSON.stringify(expectedReports)) throw new Error(`report boundary mismatch:${actual.join(',')}`);
  process.stdout.write(run.stdout);
}
try {
  await main();
} catch (error) {
  await cleanReports();
  console.error(error.message || String(error));
  process.exit(Number.isInteger(error.exitCode) ? error.exitCode : 1);
}
