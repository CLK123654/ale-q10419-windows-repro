# search-admin-console离线供应链材料

package-lock.json是待审lockfile，rules/license_policy.json定义许可证别名、许可分层、报告日期和漏洞门禁，security/vulnerability_feed.json是离线漏洞摘要，owners.csv提供精确与作用域归属，starter/audit_release_deps.mjs是待修脚本。所有材料均为脱敏演练数据，不访问npm registry或外部漏洞服务。

把完成版程序保存到output/src/audit_release_deps.mjs。在Windows PowerShell、macOS或Linux终端进入input_data并运行node tools/run_task.mjs，入口使用同一node.exe执行程序并生成output/reports。报告供发布工程、开源合规和安全运营共同复核。
